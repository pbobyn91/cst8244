# SigHandler

## Status

The status of lab 3 is that it is complete. The lab works and it behaves as expected. It creates a process and then prints the 
PID to the screen and waits for the Neutrino to send the stop signal to end the process. When that happens the console prints 
out a message and says that it is exiting. Then the program stops running. It does this same process for each of the child 
processes to.

## Known Issues

I am not sure if this is just my desktop or my install of momentics but sometimes when I first start up momentics it doesn't 
register that part A is there. When I look at the .c file for part A it says its missing the included c files. When I restart 
momentics this problem has always gone away. It could also be that the Neutrino was not running at the time and when I did the
restart the Neutrino was online. 

## Expected Grade

Assuming you don't run into the same issue I listed above I am expecting full marks. Otherwise I am expecting maybe a 7/10. 
