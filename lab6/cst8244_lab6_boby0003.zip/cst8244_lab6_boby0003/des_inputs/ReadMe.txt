Title: des_inputs

Author: @came0351@algonquinlive.com			


Contribution: I worked on the des_inputs project, while Patrick worked on the des_display project. We both
			  worked hand in hand on the controller, testing and finding issues. It was a solid group effort.

Status:  The project works as expected and meets all specification and requirements assigned
		 No missing requirements or runtime errors.

Known Issues: N/A

Expected Grade: A+