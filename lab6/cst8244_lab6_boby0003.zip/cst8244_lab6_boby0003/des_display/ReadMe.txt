Title: des_display

Author: @pboby0003@algonquinlive.com			


Contribution: 	I wrote the des_display file. John worked on the des_inputs portion of the project. 
		We both worked on the controller while trying to find the optimal way to get it to work 
		with our state machine.

Status:  The project works as expected and meets all specification and requirements assigned
		 No missing requirements or runtime errors.

Known Issues: N/A

Expected Grade: A+